# Entregable 6

Websockets

## hbs 
/

```
npm start
```

```
http://localhost:8088/productos
```
